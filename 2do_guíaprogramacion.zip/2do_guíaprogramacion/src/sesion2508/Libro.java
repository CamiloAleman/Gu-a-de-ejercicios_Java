/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sesion2508;

/**
 *
 * @author labc205
 */
public class Libro {
    
    private int id;
    private String producto;
    private double precio;
    private String autor;
    private String descripcion;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
    public Libro(int id, String producto, double precio, String autor, String descripcion) {
        this.id = id;
        this.producto = producto;
        this.precio = precio;
        this.autor = autor;
        this.descripcion = descripcion;
    }
    
    
    

    @Override
    public String toString() {
        return + id  +  " | " + producto + " | " + precio + " | " + autor + " | " + descripcion + "\n";
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    
    
}
