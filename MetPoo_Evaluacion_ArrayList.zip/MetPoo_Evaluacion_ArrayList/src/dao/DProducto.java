package dao;

import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import modelos.Producto;

/**
 *
 * @author 
 */
public class DProducto {
    private ArrayList<Producto> listProducto = new ArrayList<>();
    
    public DProducto() {
    }
    
    public DProducto(ArrayList<Producto> listProducto) {
        this.listProducto = listProducto;
    }

    public ArrayList<Producto> getListProducto() {
        return listProducto;
    }
    
    public void setListProducto(ArrayList<Producto> listProducto) {
        this.listProducto = listProducto;
    }
    
    public int agregarProducto(int codigo, int precio, 
            int existencia, String nombre) {
        int b = 0;
        Producto prod = new Producto(codigo, precio, existencia, nombre);
        listProducto.add(prod);
        b = 1;
        return b;
    }
 
    public DefaultTableModel getListProd() {
        DefaultTableModel dtm = new DefaultTableModel();
        
        
        String titulo[] = {"CÓDIGO", "NOMBRE", "PRECIO ($USD)", "EXISTENCIA"};
        
        dtm.setColumnIdentifiers(titulo);
        
        for (Producto prod: listProducto) {
            String reg[] = new String[4];
            reg[0] = "" + prod.getCodigoProd();
            reg[1] = "" + prod.getNombreProd();
            reg[2] = "" + prod.getPrecioProd();
            reg[3] = "" + prod.getExistenciaProd();
            
            dtm.addRow(reg);
        }
        return dtm;
    }
}
