/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_tarea1;

/**
 *
 * @author USUARIO
 */

import java.util.Scanner;

public class Principal_Tarea1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner datos = new Scanner(System.in);
        
        Trabajador primero = new Trabajador();
        String nombreTrabajador;
        String apellidoTrabajador;
        int codigoTrabajador;
        double salarioTrabajador;
        
        System.out.println("Ingrese su nombre");
         nombreTrabajador = datos.nextLine();
         primero.setNombre(nombreTrabajador);
        
        System.out.println("Ingrese su apellido");
        apellidoTrabajador = datos.nextLine();
        primero.setApellidos(apellidoTrabajador);
        
        System.out.println("Ingrese su codigo");
        codigoTrabajador = datos.nextInt();
        primero.setCodigo(codigoTrabajador);
        
        System.out.println("Ingrese su salario mensual");
        salarioTrabajador = datos.nextDouble();
        primero.setSalario(salarioTrabajador);
        
        System.out.println("Datos del trabajador: ");
            System.out.println("Nombre: " + primero.getNombre());
            System.out.println("Apellido: " + primero.getApellidos());
            System.out.println("Codigo: " + primero.getCodigo());
            System.out.println("Salario Mensual: " + primero.getSalario());
        System.out.println("Y el salario diario es de " + primero.getSalario() / 30);
    }
    
}
